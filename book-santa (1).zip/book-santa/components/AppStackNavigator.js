import React from 'react';
import { createStackNavigator } from 'react-navigation-stack';
import BookDonateScreen from '../Screens/bookDonateScreen';
import ReceiverDetailsScreen from '../Screens/receiverDetailsScreen';

export const AppStackNavigator = createStackNavigator({
  bookDonateList: {
    screen: BookDonateScreen,
    navigationOptions: {
      headerShown: false
    }
  },
  receiverDetails: {
    screen: ReceiverDetailsScreen,
    navigationOptions: {
      headerShown: false
    }
  },
},
{
  initialRouteName: 'bookDonateList'
});