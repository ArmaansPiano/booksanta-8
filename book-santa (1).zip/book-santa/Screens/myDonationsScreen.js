import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Flatlist,
  StyleSheet,
} from 'react-native';
import { Card, Icon, ListItem } from 'react-native-elements';
import MyHeader from '../components/MyHeader';
import firebase from 'firebase';
import Db from '../config';

export default class MyDonationsScreen extends Component {
  constructor() {
    super();
    this.state = {
      donorId: firebase.auth().currentUser.email,
      donorName: '',
      allDonations: [],
    };
    this.requestRef = null;
  }
  static navigationOptions = {
    header: null,
  };
  getDonorDetails = (donorId) => {
    Db.collection('users')
      .where('emailId', '==', donorId)
      .get()
      .then((snapshot) => {
        snapshot.forEach((doc) => {
          this.setState({
            donorName: doc.data().first_name + '' + doc.data().last_name,
          });
        });
      });
  };

  getAllDonations = () => {
    this.requestRef = Db.collection('all_donations')
      .where('donor_id', '==', this.state.donorId)
      .onSnapshot((snapshot) => {
        var allDonations = [];
        snapshot.docs.map((doc) => {
          var donation = doc.data();
          donation['doc_id'] = doc.id;
          allDonations.push(donation);
        });
        this.setState({
          allDonations: allDonations,
        });
      });
  };

  sendBook = (bookDetails) => {
    if (bookDetails.request_status === 'book sent') {
      var requestStatus = 'donor interested';
      Db.collection('all_donations').doc(bookDetails.doc_id).update({
        request_status: 'donor interested',
      });

      this.sendNotification(bookDetails, requestStatus);
    } else {
      var requestStatus = 'book sent';
      Db.collection('all_donations').doc(bookDetails.doc_id).update({
        request_status: 'book_sent',
      });

      this.sendNotification(bookDetails, requestStatus);
    }
  };

  sendNotification = (bookDetails, requestStatus) => {
    var requestId = bookDetails.request_id;
    var donorId = bookDetails.donor_id;
    Db.collection('all_notifications')
      .where('request_id', '==', requestId)
      .where('donor_id', '==', donorId)
      .get()
      .then((snapshot) => {
        snapshot.forEach((doc) => {
          var message = '';
          if (requestStatus === 'book sent') {
            message = this.state.donorName + 'sent you a book!';
          } else {
            message = this.state.donorName+"has shown interest in donating your book."
          }

          Db.collection("all_notifications").doc(doc.id).update({
            "message": message,
            "notification_status": "unread",
            "date": firebase.firestore.FieldValue.serverTimestamp()
          });
        });
      });
  };

  keyExtractor = (item, index)=> index.toString()
  renderItem = ({item, i})=> {
    <ListItem
    key = {i}
    title = {item.book_name}
    subtitle = {"requestedBy:"+item.requested_by+"\n status:"+item.request_status}
    leftElement = {<Icon name = "book" type = "font-awesome" color = "red"/>}
    titleStyle = {{color: 'red', fontWeight: 'bold'}}
    rightElement = {<TouchableOpacity style={[styles.button, {backgroundColor: item.request_status==="book sent"?"green":"red"}]}
    onPress = {()=> {
      this.sendBook(item)
    }}>
    <Text style={{color: 'white'}}>{
      item.request_status === "book sent"?"book sent":"send book"}
      </Text>
      </TouchableOpacity>
    }
    bottomDivider
    />
    )
    }
  }
}
